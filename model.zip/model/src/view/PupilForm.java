package view;

import model.Pupil;
import controller.PupilProcessor;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;

public class PupilForm extends javax.swing.JFrame {
    private DefaultTableModel model;

    public PupilForm() {
        initComponents();
        model = (DefaultTableModel) this.jTable1.getModel();
    }

    private void initComponents() {
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setText("Connect");
        jButton1.addActionListener(evt -> jButton1ActionPerformed(evt));

        jButton2.setText("Select");
        jButton2.addActionListener(evt -> jButton2ActionPerformed(evt));

        jButton3.setText("Insert");
        jButton3.addActionListener(evt -> jButton3ActionPerformed(evt));

        jButton4.setText("Close");
        jButton4.addActionListener(evt -> jButton4ActionPerformed(evt));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object[][] {},
            new String[] {"ID", "Name", "Grade 1", "Grade 2", "Average", "Status"}
        ) {
            Class[] types = new Class[] {
                java.lang.String.class, java.lang.String.class, java.lang.Double.class, java.lang.Double.class, java.lang.Double.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types[columnIndex];
            }
        });
        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 452, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addGap(34, 34, 34)
                        .addComponent(jButton2)
                        .addGap(44, 44, 44)
                        .addComponent(jButton3)
                        .addGap(52, 52, 52)
                        .addComponent(jButton4)))
                .addContainerGap(30, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3)
                    .addComponent(jButton4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 356, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        pack();
    }

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
        // Handle connect button action here.
    }

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {
        PupilProcessor processor = new PupilProcessor(new ArrayList<>());
        ArrayList<Pupil> pupils = processor.getPupils();
        model.setRowCount(0);
        for (Pupil pupil : pupils) {
            model.addRow(new Object[]{pupil.id, pupil.name, pupil.grade1, pupil.grade2, pupil.calculateAverage(), pupil.determineStatus()});
        }
    }

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {
        
    }

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {
        
    }


    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
}
