/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;
//fernando  m   uñoz
//Max Ontaneda
import model.Pupil;
import model.DBConnector;
import java.util.ArrayList;

public class PupilProcessor {
    private ArrayList<Pupil> pupils;

    public PupilProcessor(ArrayList<Pupil> pupils) {
        this.pupils = pupils;
    }

    public void insertPupil(Pupil pupil) {
        new DBConnector().insertPupil(pupil);
    }

    public void updatePupil(Pupil pupil) {
        new DBConnector().updatePupil(pupil);
    }

    public void deletePupil(String id) {
        new DBConnector().deletePupil(id);
    }

    public ArrayList<Pupil> getPupils() {
        return new DBConnector().getPupils();
    }
}