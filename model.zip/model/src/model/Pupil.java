/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package model;

/**
 *
 * @author marga
 */
public class Pupil {
    public String id;
    public String name;
    public double grade1;
    public double grade2;

    public Pupil(String id, String name, double grade1, double grade2) {
        this.id = id;
        this.name = name;
        this.grade1 = grade1;
        this.grade2 = grade2;
    }

    public double calculateAverage() {
        return (grade1 + grade2) / 2;
    }

    public String determineStatus() {
        return (calculateAverage() >= 7) ? "Approved" : "Failed";
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getGrade1() {
        return grade1;
    }

    public void setGrade1(double grade1) {
        this.grade1 = grade1;
    }

    public double getGrade2() {
        return grade2;
    }

    public void setGrade2(double grade2) {
        this.grade2 = grade2;
    }

    

    @Override
    public String toString() {
        return "Pupil{" + "id=" + id + ", name=" + name + ", grade1=" + grade1 + ", grade2=" + grade2 + ", average=" + calculateAverage() + ", status=" + determineStatus() + '}';
    }
}