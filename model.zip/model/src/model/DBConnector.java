/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.*;
import java.util.ArrayList;

public class DBConnector {
    private Connection connection;
    private ArrayList<Pupil> pupils;
    private String message;

    public void connect() {
        try {
            String url = "jdbc:sqlite:db/test.db";
            connection = DriverManager.getConnection(url);
        } catch (SQLException e) {
            message = e.getMessage();
        }
    }

    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            message = e.getMessage();
        }
    }

    public ArrayList<Pupil> getPupils() {
        pupils = new ArrayList<>();
        try {
            connect();
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM Pupil");
            while (resultSet.next()) {
                Pupil pupil = new Pupil(
                    resultSet.getString("id"),
                    resultSet.getString("name"),
                    resultSet.getDouble("grade1"),
                    resultSet.getDouble("grade2")
                );
                pupils.add(pupil);
            }
            statement.close();
        } catch (SQLException e) {
            message = e.getMessage();
        } finally {
            close();
        }
        return pupils;
    }

    public void insertPupil(Pupil pupil) {
        try {
            connect();
            String query = "INSERT INTO Pupil(id, name, grade1, grade2) VALUES(?,?,?,?)";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, pupil.id);
            statement.setString(2, pupil.name);
            statement.setDouble(3, pupil.grade1);
            statement.setDouble(4, pupil.grade2);
            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            message = e.getMessage();
        } finally {
            close();
        }
    }

    public void updatePupil(Pupil pupil) {
        try {
            connect();
            String query = "UPDATE Pupil SET name=?, grade1=?, grade2=? WHERE id=?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, pupil.name);
            statement.setDouble(2, pupil.grade1);
            statement.setDouble(3, pupil.grade2);
            statement.setString(4, pupil.id);
            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            message = e.getMessage();
        } finally {
            close();
        }
    }

    public void deletePupil(String id) {
        try {
            connect();
            String query = "DELETE FROM Pupil WHERE id=?";
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, id);
            statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            message = e.getMessage();
        } finally {
            close();
        }
    }
}